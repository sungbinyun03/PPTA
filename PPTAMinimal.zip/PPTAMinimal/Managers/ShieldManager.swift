//
//  ShieldManager.swift
//  PPTAMinimal
//
//  Created by Sungbin Yun on 4/10/25.
//

import Foundation
import FamilyControls
import DeviceActivity
import ManagedSettings

enum ShieldManagerError: Error {
    case noApplicationsToLock
    // Add more cases as needed.
}

class ShieldManager {
    static let shared = ShieldManager()
    private init() {}
    
    private let store = ManagedSettingsStore()

    func lockApps(duration: TimeInterval = 1 * 60) throws {
            store.clearAllSettings()
            print("CALLED @@@@@@@")
            let applications = UserSettingsManager.shared.userSettings.applications.applicationTokens
            let categories = UserSettingsManager.shared.userSettings.applications.categoryTokens
            
            guard !applications.isEmpty || !categories.isEmpty else {
                    throw ShieldManagerError.noApplicationsToLock
                }
            store.shield.applications = applications.isEmpty ? nil : applications
            store.shield.applicationCategories = categories.isEmpty ? nil : .specific(categories)
            store.shield.webDomainCategories = categories.isEmpty ? nil : .specific(categories)
        
            DispatchQueue.main.asyncAfter(deadline: .now() + duration) { [weak self] in
                        print("[Extension ShieldManager] Unlocking apps.")
                        self?.store.shield.applications = nil
                    }
        }

    func unlockApps() {
        print("[ShieldManager] Unlocking apps.")
        store.shield.applications = nil
    }
}
